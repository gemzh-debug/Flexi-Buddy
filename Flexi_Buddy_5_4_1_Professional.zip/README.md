# Flexi Buddy 5.4.1 Professional

## New in this build
- Functional one-tap work modes: WFH, Office, Home Visits and Hybrid
- Live finish card that updates as work and quick-work minutes are recorded
- Start/stop paid-travel assistant
- Floating Quick Add available from every screen
- Quick Add for email/messages, meeting, break, lunch, travel and diary notes
- Code split into `styles.css` and `app.js` for safer future updates
- Existing `flexiBuddyDataV1` data remains compatible

Upload every file in this folder to the root of the GitHub Pages repository.
